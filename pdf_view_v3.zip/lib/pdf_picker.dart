import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show Uint8List, kIsWeb;
import 'package:pdf_render/pdf_render_widgets.dart';
import 'package:three/fade_atom.dart';

class PdfUploadScreen extends StatefulWidget {
  const PdfUploadScreen({super.key});

  @override
  _PdfUploadScreenState createState() => _PdfUploadScreenState();
}

class _PdfUploadScreenState extends State<PdfUploadScreen> {
  Uint8List? fileBytes;
  List<List<dynamic>> fields = [];

  int curentPage = 1;

  Future<Uint8List> _openFileExplorerWeb() async {
    // File picker
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null) {
      setState(() {
        curentPage = 1;
        fileBytes = result.files.first.bytes!;
      });
    }

    return Uint8List.fromList([]);
  }

  // PDF Controller
  PdfViewerController? controller;

  // init a state
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Text('Chordcast'),
            Spacer(),
            ElevatedButton(
              style: ButtonStyle(
                backgroundColor:
                    MaterialStateProperty.all(Color.fromARGB(255, 0, 0, 0)),
              ),
              onPressed: _openFileExplorerWeb,
              child: const Text('Pick PDF file'),
            )
          ],
        ),
      ),
      body: Center(
        child: Stack(
          children: [
            Builder(builder: (context) {
              if (fileBytes == null) {
                return Center(
                    child: FadeAtom(child: Text('Select file, please')));
              } else {
                return Center(
                    child: FadeAtom(
                  child: PdfDocumentLoader.openData(
                    fileBytes!,
                    pageNumber: curentPage,
                    pageBuilder: (context, textureBuilder, pageSize) =>
                        FadeAtom(
                            child: textureBuilder(
                      backgroundFill: true,
                      placeholderBuilder: (size, status) {
                        return FadeAtom(
                          withMovement: false,
                          child: Container(
                            color: Colors.white,
                            child: SizedBox(
                              height: 500,
                              width: 400,
                            ),
                          ),
                        );
                      },
                    )),
                  ),
                ));
              }
            }),
            Align(
              alignment: Alignment.centerLeft,
              child: GestureDetector(
                onTap: () {
                  previousPage();
                },
                child: Container(
                  height: double.maxFinite,
                  width: MediaQuery.of(context).size.width / 3,
                  color: Color.fromRGBO(0, 0, 0, 0),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: GestureDetector(
                onTap: () {
                  nextPage();
                },
                child: Container(
                  height: double.maxFinite,
                  width: MediaQuery.of(context).size.width / 3,
                  color: Color.fromRGBO(0, 0, 0, 0),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  void previousPage() {
    if (curentPage > 1) {
      var newPage = curentPage - 1;
      controller?.goToPage(pageNumber: newPage);
      setState(() {
        curentPage = newPage;
      });
    }
  }

  void nextPage() {
    try {
      var newPage = curentPage + 1;
      controller?.goToPage(pageNumber: newPage);
      setState(() {
        curentPage = newPage;
      });
    } catch (e) {}
  }
}
